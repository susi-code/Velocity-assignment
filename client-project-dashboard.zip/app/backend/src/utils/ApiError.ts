export type ErrorCode =
  | "VALIDATION_ERROR"
  | "UNAUTHENTICATED"
  | "FORBIDDEN"
  | "NOT_FOUND"
  | "CONFLICT"
  | "INTERNAL_ERROR";

const statusByCode: Record<ErrorCode, number> = {
  VALIDATION_ERROR: 400,
  UNAUTHENTICATED: 401,
  FORBIDDEN: 403,
  NOT_FOUND: 404,
  CONFLICT: 409,
  INTERNAL_ERROR: 500,
};

export class ApiError extends Error {
  code: ErrorCode;
  status: number;
  details?: unknown;

  constructor(code: ErrorCode, message: string, details?: unknown) {
    super(message);
    this.code = code;
    this.status = statusByCode[code];
    this.details = details;
  }

  static validation(message: string, details?: unknown) {
    return new ApiError("VALIDATION_ERROR", message, details);
  }
  static unauthenticated(message = "Authentication required") {
    return new ApiError("UNAUTHENTICATED", message);
  }
  static forbidden(message = "You do not have permission to access this resource") {
    return new ApiError("FORBIDDEN", message);
  }
  static notFound(message = "Resource not found") {
    return new ApiError("NOT_FOUND", message);
  }
  static conflict(message: string) {
    return new ApiError("CONFLICT", message);
  }
}
