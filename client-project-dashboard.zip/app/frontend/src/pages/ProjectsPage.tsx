import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { Link } from "react-router-dom";
import { projectsApi, clientsApi } from "../api/endpoints";
import { useAuthStore } from "../store/authStore";
import { Card } from "../components/Card";
import { extractErrorMessage } from "../api/client";

export function ProjectsPage() {
  const user = useAuthStore((s) => s.user)!;
  const queryClient = useQueryClient();
  const [showForm, setShowForm] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [form, setForm] = useState({ name: "", description: "", clientId: "" });

  const { data: projects, isLoading } = useQuery({
    queryKey: ["projects"],
    queryFn: () => projectsApi.list().then((r) => r.data.data),
  });
  const { data: clients } = useQuery({
    queryKey: ["clients"],
    queryFn: () => clientsApi.list().then((r) => r.data.data),
    enabled: showForm,
  });

  const createMutation = useMutation({
    mutationFn: () => projectsApi.create(form),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["projects"] });
      setShowForm(false);
      setForm({ name: "", description: "", clientId: "" });
      setError(null);
    },
    onError: (err) => setError(extractErrorMessage(err)),
  });

  const canCreate = user.role === "ADMIN" || user.role === "PROJECT_MANAGER";

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-bold text-slate-800">Projects</h1>
        {canCreate && (
          <button
            onClick={() => setShowForm((s) => !s)}
            className="rounded-md bg-brand-600 px-4 py-2 text-sm font-semibold text-white hover:bg-brand-700"
          >
            {showForm ? "Cancel" : "New Project"}
          </button>
        )}
      </div>

      {showForm && (
        <Card>
          <form
            className="grid gap-3 sm:grid-cols-2"
            onSubmit={(e) => {
              e.preventDefault();
              createMutation.mutate();
            }}
          >
            <input
              required
              placeholder="Project name"
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
              className="rounded-md border border-slate-300 px-3 py-2 text-sm sm:col-span-2"
            />
            <textarea
              required
              placeholder="Description"
              value={form.description}
              onChange={(e) => setForm({ ...form, description: e.target.value })}
              className="rounded-md border border-slate-300 px-3 py-2 text-sm sm:col-span-2"
            />
            <select
              required
              value={form.clientId}
              onChange={(e) => setForm({ ...form, clientId: e.target.value })}
              className="rounded-md border border-slate-300 px-3 py-2 text-sm sm:col-span-2"
            >
              <option value="">Select client...</option>
              {clients?.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.company}
                </option>
              ))}
            </select>
            {error && <p className="text-sm text-red-600 sm:col-span-2">{error}</p>}
            <button
              type="submit"
              disabled={createMutation.isPending}
              className="rounded-md bg-brand-600 px-4 py-2 text-sm font-semibold text-white hover:bg-brand-700 sm:col-span-2"
            >
              Create Project
            </button>
          </form>
        </Card>
      )}

      {isLoading && <p className="text-sm text-slate-400">Loading projects...</p>}

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {projects?.map((p) => (
          <Link key={p.id} to={`/projects/${p.id}`}>
            <Card className="h-full transition-shadow hover:shadow-md">
              <p className="font-semibold text-slate-800">{p.name}</p>
              <p className="mt-1 line-clamp-2 text-sm text-slate-500">{p.description}</p>
              <div className="mt-3 flex items-center justify-between text-xs text-slate-400">
                <span>{p.client?.company}</span>
                <span>{p._count?.tasks ?? 0} tasks</span>
              </div>
            </Card>
          </Link>
        ))}
      </div>

      {projects?.length === 0 && !isLoading && (
        <p className="py-10 text-center text-sm text-slate-400">No projects visible to your account yet.</p>
      )}
    </div>
  );
}
