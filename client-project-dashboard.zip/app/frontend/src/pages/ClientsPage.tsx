import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { clientsApi } from "../api/endpoints";
import { Card } from "../components/Card";
import { extractErrorMessage } from "../api/client";

export function ClientsPage() {
  const queryClient = useQueryClient();
  const [showForm, setShowForm] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [form, setForm] = useState({ name: "", email: "", company: "" });

  const { data: clients } = useQuery({ queryKey: ["clients"], queryFn: () => clientsApi.list().then((r) => r.data.data) });

  const createClient = useMutation({
    mutationFn: () => clientsApi.create(form),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["clients"] });
      setShowForm(false);
      setForm({ name: "", email: "", company: "" });
      setError(null);
    },
    onError: (err) => setError(extractErrorMessage(err)),
  });

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-bold text-slate-800">Clients</h1>
        <button
          onClick={() => setShowForm((s) => !s)}
          className="rounded-md bg-brand-600 px-4 py-2 text-sm font-semibold text-white hover:bg-brand-700"
        >
          {showForm ? "Cancel" : "New Client"}
        </button>
      </div>

      {showForm && (
        <Card>
          <form
            className="grid gap-3 sm:grid-cols-3"
            onSubmit={(e) => {
              e.preventDefault();
              createClient.mutate();
            }}
          >
            <input
              required
              placeholder="Contact name"
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
              className="rounded-md border border-slate-300 px-3 py-2 text-sm"
            />
            <input
              required
              type="email"
              placeholder="Email"
              value={form.email}
              onChange={(e) => setForm({ ...form, email: e.target.value })}
              className="rounded-md border border-slate-300 px-3 py-2 text-sm"
            />
            <input
              required
              placeholder="Company"
              value={form.company}
              onChange={(e) => setForm({ ...form, company: e.target.value })}
              className="rounded-md border border-slate-300 px-3 py-2 text-sm"
            />
            {error && <p className="text-sm text-red-600 sm:col-span-3">{error}</p>}
            <button
              type="submit"
              className="rounded-md bg-brand-600 px-4 py-2 text-sm font-semibold text-white hover:bg-brand-700 sm:col-span-3"
            >
              Add Client
            </button>
          </form>
        </Card>
      )}

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {clients?.map((c) => (
          <Card key={c.id}>
            <p className="font-semibold text-slate-800">{c.company}</p>
            <p className="text-sm text-slate-500">{c.name}</p>
            <p className="text-xs text-slate-400">{c.email}</p>
          </Card>
        ))}
      </div>
    </div>
  );
}
