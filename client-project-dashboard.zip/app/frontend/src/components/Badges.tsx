import { Priority, TaskStatus } from "../types";

const statusStyles: Record<TaskStatus, string> = {
  TODO: "bg-slate-100 text-slate-700",
  IN_PROGRESS: "bg-blue-100 text-blue-700",
  IN_REVIEW: "bg-amber-100 text-amber-800",
  DONE: "bg-emerald-100 text-emerald-700",
  OVERDUE: "bg-red-100 text-red-700",
};

const priorityStyles: Record<Priority, string> = {
  LOW: "bg-slate-100 text-slate-600",
  MEDIUM: "bg-sky-100 text-sky-700",
  HIGH: "bg-orange-100 text-orange-700",
  CRITICAL: "bg-red-100 text-red-700",
};

export function StatusBadge({ status }: { status: TaskStatus }) {
  return <span className={`badge ${statusStyles[status]}`}>{status.replace("_", " ")}</span>;
}

export function PriorityBadge({ priority }: { priority: Priority }) {
  return <span className={`badge ${priorityStyles[priority]}`}>{priority}</span>;
}

export function RoleBadge({ role }: { role: string }) {
  const styles: Record<string, string> = {
    ADMIN: "bg-brand-100 text-brand-700",
    PROJECT_MANAGER: "bg-purple-100 text-purple-700",
    DEVELOPER: "bg-teal-100 text-teal-700",
  };
  return <span className={`badge ${styles[role] ?? "bg-slate-100 text-slate-700"}`}>{role.replace("_", " ")}</span>;
}
