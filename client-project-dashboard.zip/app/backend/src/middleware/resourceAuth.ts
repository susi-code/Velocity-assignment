import { NextFunction, Request, Response } from "express";
import { prisma } from "../config/prisma";
import { ApiError } from "../utils/ApiError";

/**
 * Loads the project by :id (or :projectId) and enforces ownership:
 * - ADMIN: full access
 * - PROJECT_MANAGER: only if they created the project
 * - DEVELOPER: only if they have a task assigned to them within the project
 * Attaches the loaded project to req.project for downstream handlers.
 */
export async function authorizeProjectAccess(req: Request, _res: Response, next: NextFunction) {
  try {
    const projectId = req.params.projectId ?? req.params.id;
    if (!projectId) return next(ApiError.validation("Project id is required"));
    if (!req.user) return next(ApiError.unauthenticated());

    const project = await prisma.project.findUnique({ where: { id: projectId } });
    if (!project) return next(ApiError.notFound("Project not found"));

    if (req.user.role === "ADMIN") {
      req.project = project;
      return next();
    }

    if (req.user.role === "PROJECT_MANAGER") {
      if (project.createdById !== req.user.id) {
        return next(ApiError.forbidden());
      }
      req.project = project;
      return next();
    }

    if (req.user.role === "DEVELOPER") {
      const hasTask = await prisma.task.findFirst({
        where: { projectId: project.id, assignedDeveloperId: req.user.id },
        select: { id: true },
      });
      if (!hasTask) return next(ApiError.forbidden());
      req.project = project;
      return next();
    }

    return next(ApiError.forbidden());
  } catch (err) {
    return next(err);
  }
}

/**
 * Loads the task by :id and enforces ownership:
 * - ADMIN: full access
 * - PROJECT_MANAGER: only if they created the task's project
 * - DEVELOPER: only if the task is assigned to them
 * Attaches the loaded task (with project) to req.task.
 */
export async function authorizeTaskAccess(req: Request, _res: Response, next: NextFunction) {
  try {
    const taskId = req.params.id ?? req.params.taskId;
    if (!taskId) return next(ApiError.validation("Task id is required"));
    if (!req.user) return next(ApiError.unauthenticated());

    const task = await prisma.task.findUnique({ where: { id: taskId }, include: { project: true } });
    if (!task) return next(ApiError.notFound("Task not found"));

    if (req.user.role === "ADMIN") {
      req.task = task;
      return next();
    }

    if (req.user.role === "PROJECT_MANAGER") {
      if (task.project.createdById !== req.user.id) {
        return next(ApiError.forbidden());
      }
      req.task = task;
      return next();
    }

    if (req.user.role === "DEVELOPER") {
      if (task.assignedDeveloperId !== req.user.id) {
        return next(ApiError.forbidden());
      }
      req.task = task;
      return next();
    }

    return next(ApiError.forbidden());
  } catch (err) {
    return next(err);
  }
}

declare global {
  // eslint-disable-next-line @typescript-eslint/no-namespace
  namespace Express {
    interface Request {
      project?: import("@prisma/client").Project;
      task?: import("@prisma/client").Task & { project: import("@prisma/client").Project };
    }
  }
}
