import { Router } from "express";
import { authenticate } from "../middleware/auth";
import { asyncHandler } from "../middleware/errorHandler";
import * as activityService from "../services/activityService";
import { z } from "zod";

const router = Router();
router.use(authenticate);

// Latest 20 relevant activities (used on initial dashboard load).
router.get(
  "/",
  asyncHandler(async (req, res) => {
    const activities = await activityService.getRecentActivityForUser(req.user!);
    res.json({ success: true, data: activities });
  })
);

// Missed-event catch-up after reconnect: ?since=<ISO timestamp>
router.get(
  "/catchup",
  asyncHandler(async (req, res) => {
    const schema = z.object({ since: z.coerce.date() });
    const { since } = schema.parse(req.query);
    const activities = await activityService.getActivitySince(req.user!, since);
    res.json({ success: true, data: activities });
  })
);

export default router;
