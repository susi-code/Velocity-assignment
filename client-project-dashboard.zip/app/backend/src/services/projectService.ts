import { Prisma, Role } from "@prisma/client";
import { prisma } from "../config/prisma";
import { ApiError } from "../utils/ApiError";

export async function listProjectsForUser(user: { id: string; role: Role }) {
  let where: Prisma.ProjectWhereInput = {};
  if (user.role === "PROJECT_MANAGER") {
    where = { createdById: user.id };
  } else if (user.role === "DEVELOPER") {
    where = { tasks: { some: { assignedDeveloperId: user.id } } };
  }

  return prisma.project.findMany({
    where,
    include: {
      client: true,
      createdBy: { select: { id: true, name: true } },
      _count: { select: { tasks: true } },
    },
    orderBy: { createdAt: "desc" },
  });
}

export async function getProjectDetail(projectId: string) {
  const project = await prisma.project.findUnique({
    where: { id: projectId },
    include: {
      client: true,
      createdBy: { select: { id: true, name: true } },
      tasks: { include: { assignedDeveloper: { select: { id: true, name: true } } } },
    },
  });
  if (!project) throw ApiError.notFound("Project not found");
  return project;
}

export async function createProject(
  creator: { id: string; role: Role },
  data: { name: string; description: string; clientId: string }
) {
  if (creator.role !== "ADMIN" && creator.role !== "PROJECT_MANAGER") {
    throw ApiError.forbidden();
  }
  const client = await prisma.client.findUnique({ where: { id: data.clientId } });
  if (!client) throw ApiError.validation("Client does not exist");

  return prisma.project.create({
    data: { ...data, createdById: creator.id },
  });
}

export async function updateProject(projectId: string, data: Partial<{ name: string; description: string; clientId: string }>) {
  return prisma.project.update({ where: { id: projectId }, data });
}

export async function deleteProject(projectId: string) {
  await prisma.task.deleteMany({ where: { projectId } });
  await prisma.activityLog.deleteMany({ where: { projectId } });
  await prisma.project.delete({ where: { id: projectId } });
}
