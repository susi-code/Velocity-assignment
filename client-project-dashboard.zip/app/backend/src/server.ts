import http from "http";
import { createApp } from "./app";
import { env } from "./config/env";
import { initSockets } from "./sockets";
import { startOverdueJob } from "./jobs/overdueJob";

const app = createApp();
const server = http.createServer(app);

initSockets(server);
startOverdueJob();

server.listen(env.port, () => {
  console.log(`Backend listening on http://localhost:${env.port}`);
});
