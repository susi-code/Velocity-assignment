import { NotificationType, Prisma } from "@prisma/client";
import { prisma } from "../config/prisma";
import { emitNotification, emitNotificationCount } from "../sockets";

type Tx = Prisma.TransactionClient;

export async function createNotification(
  tx: Tx,
  data: {
    recipientId: string;
    projectId?: string | null;
    taskId?: string | null;
    type: NotificationType;
    message: string;
  }
) {
  return tx.notification.create({ data });
}

export async function pushNotificationRealtime(recipientId: string, notification: unknown) {
  emitNotification(recipientId, notification);
  const count = await prisma.notification.count({ where: { recipientId, isRead: false } });
  emitNotificationCount(recipientId, count);
}

export async function listNotifications(userId: string) {
  return prisma.notification.findMany({
    where: { recipientId: userId },
    orderBy: { createdAt: "desc" },
    take: 50,
  });
}

export async function markRead(userId: string, notificationId: string) {
  const notif = await prisma.notification.findUnique({ where: { id: notificationId } });
  if (!notif || notif.recipientId !== userId) return null;
  const updated = await prisma.notification.update({
    where: { id: notificationId },
    data: { isRead: true },
  });
  const count = await prisma.notification.count({ where: { recipientId: userId, isRead: false } });
  emitNotificationCount(userId, count);
  return updated;
}

export async function markAllRead(userId: string) {
  await prisma.notification.updateMany({ where: { recipientId: userId, isRead: false }, data: { isRead: true } });
  emitNotificationCount(userId, 0);
}
