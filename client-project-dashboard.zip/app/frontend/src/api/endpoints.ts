import { api } from "./client";
import { ActivityLog, Client, Notification, Project, Task, User } from "../types";

export const authApi = {
  login: (email: string, password: string) => api.post("/auth/login", { email, password }),
  logout: () => api.post("/auth/logout"),
  me: () => api.get<{ success: true; data: User }>("/auth/me"),
};

export const projectsApi = {
  list: () => api.get<{ success: true; data: Project[] }>("/projects"),
  get: (id: string) => api.get<{ success: true; data: Project }>(`/projects/${id}`),
  create: (data: { name: string; description: string; clientId: string }) =>
    api.post<{ success: true; data: Project }>("/projects", data),
  update: (id: string, data: Partial<{ name: string; description: string; clientId: string }>) =>
    api.patch<{ success: true; data: Project }>(`/projects/${id}`, data),
  remove: (id: string) => api.delete(`/projects/${id}`),
};

export const tasksApi = {
  listForProject: (projectId: string, params: Record<string, string | undefined>) =>
    api.get<{ success: true; data: Task[] }>(`/projects/${projectId}/tasks`, { params }),
  mine: () => api.get<{ success: true; data: Task[] }>("/tasks/mine"),
  get: (id: string) => api.get<{ success: true; data: Task }>(`/tasks/${id}`),
  create: (
    projectId: string,
    data: { title: string; description: string; assignedDeveloperId?: string | null; priority: string; dueDate: string }
  ) => api.post<{ success: true; data: Task }>(`/projects/${projectId}/tasks`, data),
  update: (id: string, data: Partial<{ title: string; description: string; assignedDeveloperId: string | null; priority: string; dueDate: string }>) =>
    api.patch<{ success: true; data: Task }>(`/tasks/${id}`, data),
  updateStatus: (id: string, status: string) =>
    api.patch<{ success: true; data: Task }>(`/tasks/${id}/status`, { status }),
  remove: (id: string) => api.delete(`/tasks/${id}`),
};

export const activityApi = {
  recent: () => api.get<{ success: true; data: ActivityLog[] }>("/activity"),
  catchup: (since: string) => api.get<{ success: true; data: ActivityLog[] }>("/activity/catchup", { params: { since } }),
};

export const notificationsApi = {
  list: () => api.get<{ success: true; data: Notification[] }>("/notifications"),
  markRead: (id: string) => api.patch(`/notifications/${id}/read`),
  markAllRead: () => api.patch("/notifications/read-all"),
};

export const usersApi = {
  list: () => api.get<{ success: true; data: User[] }>("/users"),
  developers: () => api.get<{ success: true; data: User[] }>("/users/developers"),
  create: (data: { name: string; email: string; password: string; role: string }) =>
    api.post<{ success: true; data: User }>("/users", data),
};

export const clientsApi = {
  list: () => api.get<{ success: true; data: Client[] }>("/clients"),
  create: (data: { name: string; email: string; company: string }) =>
    api.post<{ success: true; data: Client }>("/clients", data),
};

export const statsApi = {
  admin: () =>
    api.get<{
      success: true;
      data: {
        totalProjects: number;
        totalTasks: number;
        tasksByStatus: { status: string; count: number }[];
        overdueCount: number;
        onlineUsers: number;
      };
    }>("/stats/admin"),
};
