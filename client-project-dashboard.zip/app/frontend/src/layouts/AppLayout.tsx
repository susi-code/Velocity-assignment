import { NavLink, Outlet, useNavigate } from "react-router-dom";
import { useQueryClient } from "@tanstack/react-query";
import { useAuthStore } from "../store/authStore";
import { authApi } from "../api/endpoints";
import { NotificationBell } from "../components/NotificationBell";
import { RoleBadge } from "../components/Badges";
import { useSocket } from "../hooks/useSocket";

const navByRole: Record<string, { to: string; label: string }[]> = {
  ADMIN: [
    { to: "/dashboard", label: "Dashboard" },
    { to: "/projects", label: "Projects" },
    { to: "/clients", label: "Clients" },
    { to: "/users", label: "Users" },
    { to: "/notifications", label: "Notifications" },
  ],
  PROJECT_MANAGER: [
    { to: "/dashboard", label: "Dashboard" },
    { to: "/projects", label: "Projects" },
    { to: "/clients", label: "Clients" },
    { to: "/notifications", label: "Notifications" },
  ],
  DEVELOPER: [
    { to: "/dashboard", label: "Dashboard" },
    { to: "/projects", label: "Projects" },
    { to: "/notifications", label: "Notifications" },
  ],
};

export function AppLayout() {
  const { user, clearAuth } = useAuthStore();
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  // Keep the notification bell live across the whole app - no polling.
  useSocket({
    onNotificationNew: () => queryClient.invalidateQueries({ queryKey: ["notifications"] }),
    onNotificationCount: () => queryClient.invalidateQueries({ queryKey: ["notifications"] }),
  });

  if (!user) return null;

  const links = navByRole[user.role] ?? [];

  async function handleLogout() {
    try {
      await authApi.logout();
    } finally {
      clearAuth();
      navigate("/login");
    }
  }

  return (
    <div className="flex min-h-screen bg-slate-50">
      <aside className="hidden w-60 flex-col border-r border-slate-200 bg-white px-4 py-6 sm:flex">
        <div className="mb-8 px-2">
          <p className="text-lg font-bold text-brand-700">Agency Dashboard</p>
        </div>
        <nav className="flex flex-1 flex-col gap-1">
          {links.map((link) => (
            <NavLink
              key={link.to}
              to={link.to}
              className={({ isActive }) =>
                `rounded-md px-3 py-2 text-sm font-medium transition-colors ${
                  isActive ? "bg-brand-50 text-brand-700" : "text-slate-600 hover:bg-slate-100"
                }`
              }
            >
              {link.label}
            </NavLink>
          ))}
        </nav>
        <button
          onClick={handleLogout}
          className="mt-4 rounded-md px-3 py-2 text-left text-sm font-medium text-slate-500 hover:bg-slate-100"
        >
          Log out
        </button>
      </aside>

      <div className="flex flex-1 flex-col">
        <header className="flex items-center justify-between border-b border-slate-200 bg-white px-6 py-3">
          <div className="text-sm text-slate-400">Internal Project Dashboard</div>
          <div className="flex items-center gap-4">
            <NotificationBell />
            <div className="flex items-center gap-2">
              <div className="text-right">
                <p className="text-sm font-medium text-slate-800">{user.name}</p>
                <RoleBadge role={user.role} />
              </div>
              <div className="flex h-9 w-9 items-center justify-center rounded-full bg-brand-100 text-sm font-semibold text-brand-700">
                {user.name.charAt(0)}
              </div>
            </div>
          </div>
        </header>

        <main className="flex-1 p-6">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
