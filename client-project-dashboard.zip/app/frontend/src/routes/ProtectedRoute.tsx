import { useEffect, useState } from "react";
import { Navigate, Outlet } from "react-router-dom";
import { useAuthStore } from "../store/authStore";
import axios from "axios";

export function ProtectedRoute({ allow }: { allow?: string[] }) {
  const { user, accessToken, setAuth, clearAuth } = useAuthStore();
  const [checking, setChecking] = useState(!accessToken);

  useEffect(() => {
    if (accessToken) {
      setChecking(false);
      return;
    }
    // On a hard refresh there's no access token in memory yet - try to silently
    // restore the session using the HttpOnly refresh cookie.
    axios
      .post("http://localhost:4000/api/auth/refresh", {}, { withCredentials: true })
      .then((res) => {
        setAuth(res.data.data.user, res.data.data.accessToken);
      })
      .catch(() => {
        clearAuth();
      })
      .finally(() => setChecking(false));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  if (checking) {
    return <div className="flex h-screen items-center justify-center text-slate-400">Loading...</div>;
  }

  if (!user) return <Navigate to="/login" replace />;
  if (allow && !allow.includes(user.role)) return <Navigate to="/dashboard" replace />;

  return <Outlet />;
}
