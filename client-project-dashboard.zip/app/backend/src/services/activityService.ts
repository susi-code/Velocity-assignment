import { Prisma, Role } from "@prisma/client";
import { prisma } from "../config/prisma";

type Tx = Prisma.TransactionClient;

export async function logActivity(
  tx: Tx,
  data: {
    projectId: string;
    taskId?: string | null;
    userId: string;
    action: string;
    oldValue?: string | null;
    newValue?: string | null;
  }
) {
  return tx.activityLog.create({ data });
}

/** Returns the most recent 20 activity log entries this user is authorized to see. */
export async function getRecentActivityForUser(user: { id: string; role: Role }) {
  const where = await buildActivityWhereForUser(user);
  return prisma.activityLog.findMany({
    where,
    orderBy: { createdAt: "desc" },
    take: 20,
    include: { user: { select: { id: true, name: true } }, task: true, project: true },
  });
}

/** Missed-event catch-up: activity after a given timestamp/id, capped at 20, authorized. */
export async function getActivitySince(user: { id: string; role: Role }, sinceCreatedAt: Date) {
  const where = await buildActivityWhereForUser(user);
  return prisma.activityLog.findMany({
    where: { ...where, createdAt: { gt: sinceCreatedAt } },
    orderBy: { createdAt: "asc" },
    take: 20,
    include: { user: { select: { id: true, name: true } }, task: true, project: true },
  });
}

async function buildActivityWhereForUser(user: { id: string; role: Role }): Promise<Prisma.ActivityLogWhereInput> {
  if (user.role === "ADMIN") {
    return {};
  }
  if (user.role === "PROJECT_MANAGER") {
    return { project: { createdById: user.id } };
  }
  // DEVELOPER: only activity tied to tasks assigned to them.
  return { task: { assignedDeveloperId: user.id } };
}
