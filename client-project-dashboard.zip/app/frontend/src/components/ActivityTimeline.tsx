import { ActivityLog } from "../types";

function describeActivity(a: ActivityLog): string {
  const who = a.user?.name ?? "Someone";
  const taskTitle = a.task?.title ?? "a task";
  if (a.action === "STATUS_CHANGED") {
    return `${who} moved "${taskTitle}" from ${a.oldValue?.replace("_", " ")} → ${a.newValue?.replace("_", " ")}`;
  }
  if (a.action === "TASK_CREATED") {
    return `${who} created task "${a.newValue}"`;
  }
  if (a.action === "TASK_OVERDUE") {
    return `Task "${taskTitle}" became overdue`;
  }
  return `${who} performed ${a.action} on "${taskTitle}"`;
}

function timeAgo(iso: string): string {
  const seconds = Math.floor((Date.now() - new Date(iso).getTime()) / 1000);
  if (seconds < 60) return "just now";
  const minutes = Math.floor(seconds / 60);
  if (minutes < 60) return `${minutes}m ago`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours}h ago`;
  return `${Math.floor(hours / 24)}d ago`;
}

export function ActivityTimeline({ activities }: { activities: ActivityLog[] }) {
  if (activities.length === 0) {
    return <p className="py-6 text-center text-sm text-slate-400">No activity yet.</p>;
  }
  return (
    <ul className="space-y-3">
      {activities.map((a) => (
        <li key={a.id} className="flex gap-3 border-b border-slate-50 pb-3 last:border-none">
          <div className="mt-1.5 h-2 w-2 flex-shrink-0 rounded-full bg-brand-500" />
          <div className="min-w-0 flex-1">
            <p className="text-sm text-slate-700">{describeActivity(a)}</p>
            <p className="text-xs text-slate-400">{timeAgo(a.createdAt)}</p>
          </div>
        </li>
      ))}
    </ul>
  );
}
