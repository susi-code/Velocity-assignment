import { Router } from "express";
import { authenticate, authorizeRoles } from "../middleware/auth";
import { asyncHandler } from "../middleware/errorHandler";
import * as clientService from "../services/clientService";
import { createClientSchema } from "../validators/schemas";

const router = Router();
router.use(authenticate);

router.get(
  "/",
  asyncHandler(async (_req, res) => {
    const clients = await clientService.listClients();
    res.json({ success: true, data: clients });
  })
);

router.post(
  "/",
  authorizeRoles("ADMIN", "PROJECT_MANAGER"),
  asyncHandler(async (req, res) => {
    const body = createClientSchema.parse(req.body);
    const client = await clientService.createClient(body);
    res.status(201).json({ success: true, data: client });
  })
);

export default router;
