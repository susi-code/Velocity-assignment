import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { notificationsApi } from "../api/endpoints";
import { Card } from "../components/Card";

export function NotificationsPage() {
  const queryClient = useQueryClient();
  const { data } = useQuery({
    queryKey: ["notifications"],
    queryFn: () => notificationsApi.list().then((r) => r.data.data),
  });

  const markRead = useMutation({
    mutationFn: (id: string) => notificationsApi.markRead(id),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["notifications"] }),
  });
  const markAllRead = useMutation({
    mutationFn: () => notificationsApi.markAllRead(),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["notifications"] }),
  });

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-bold text-slate-800">Notifications</h1>
        <button onClick={() => markAllRead.mutate()} className="text-sm font-medium text-brand-600 hover:underline">
          Mark all as read
        </button>
      </div>
      <Card>
        <ul className="divide-y divide-slate-100">
          {data?.map((n) => (
            <li key={n.id} className={`flex items-center justify-between py-3 ${n.isRead ? "" : "font-medium"}`}>
              <div>
                <p className="text-sm text-slate-700">{n.message}</p>
                <p className="text-xs text-slate-400">{new Date(n.createdAt).toLocaleString()}</p>
              </div>
              {!n.isRead && (
                <button
                  onClick={() => markRead.mutate(n.id)}
                  className="text-xs font-medium text-brand-600 hover:underline"
                >
                  Mark read
                </button>
              )}
            </li>
          ))}
          {data?.length === 0 && <p className="py-6 text-center text-sm text-slate-400">No notifications.</p>}
        </ul>
      </Card>
    </div>
  );
}
