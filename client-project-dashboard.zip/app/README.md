# Real-Time Client Project Dashboard

An internal dashboard for a small software agency to manage clients, projects, tasks,
team members, and live activity — with role-based access enforced end-to-end on the
backend (never just hidden in the UI).

> **Note on scope:** this was built to be a complete, runnable implementation of the
> core requirements as quickly as possible. A few of the more exhaustive extras from
> the original spec were simplified — see **Known Limitations** at the bottom.

---

## Features

- JWT auth with short-lived access tokens + HttpOnly, rotated refresh tokens
- Three roles (`ADMIN`, `PROJECT_MANAGER`, `DEVELOPER`) with **API-level** authorization
  and resource-ownership checks (not just hidden nav links)
- PostgreSQL + Prisma with a normalized relational schema and indexes on every
  frequently-queried column
- Real-time everything via Socket.io: task updates, role-filtered activity feed,
  live notification counts, online-user presence — no polling, no SSE
- Persistent, database-backed `ActivityLog` on every task status change, with
  missed-event catch-up for reconnecting clients
- Database-backed notifications (task assignment, PM notified on "In Review")
- `node-cron` background job that flips overdue tasks automatically, independent
  of anyone loading a page
- URL-synced task filters (`status`, `priority`, due-date range)
- Seed script with realistic, ownership-testable data
- A real Supertest suite exercising the authorization boundaries

## Tech Stack

**Frontend:** React + TypeScript + Vite, React Router, TanStack Query, Zustand,
Socket.io-client, Tailwind CSS, React Hook Form + Zod, Axios.

**Backend:** Node.js + TypeScript + Express, Socket.io, Prisma ORM, PostgreSQL,
Zod, JWT (jsonwebtoken), bcryptjs, cookie-parser, node-cron.

**Infra:** Docker Compose (Postgres only — frontend/backend run locally with `npm run dev`
for fast iteration), Prisma migrations + seed, ESLint/Prettier.

## Architecture

```
Frontend (React)
   ↓ REST (Axios, Bearer access token)
Express routes → middleware (authenticate / authorizeRoles / authorizeProjectAccess /
                 authorizeTaskAccess) → controllers (thin) → services (business logic)
   ↓
Prisma → PostgreSQL

Socket.io (JWT-authenticated handshake)
   ↓
Per-user room (user:{id}) + admin global room (global:activity)
   ↓
Server explicitly resolves WHO is allowed to see each event before emitting —
room membership alone is never treated as authorization.
```

Controllers only parse/validate and call a service; all authorization, transactions,
and side effects (activity log + notification + socket emit) live in `src/services`.

## Authentication

- **Access token:** JWT, 15m default, sent as `Authorization: Bearer <token>`, kept
  only in memory in the frontend (a Zustand store) — never in `localStorage`.
- **Refresh token:** JWT, 7d default, stored **only** in an HttpOnly cookie scoped to
  `/api/auth`. Every refresh **rotates** the token (old one is revoked in the
  `RefreshToken` table) and issues a new one. `POST /api/auth/logout` revokes it.
- Passwords are hashed with bcrypt; plaintext is never stored or logged.

## Authorization

Every protected route runs `authenticate` (verifies the JWT) and, where relevant,
`authorizeRoles(...)` (role check) **and** `authorizeProjectAccess` /
`authorizeTaskAccess` (ownership check against the database — is this PM the
project's creator, is this developer the task's assignee). The task status-update
service re-checks ownership a second time inside the transaction itself, so it's
never possible to bypass authorization by hitting the API directly with a forged
role claim — roles come only from the verified JWT, never from the request body.

## Database & Indexing

Core entities: `User`, `Client`, `Project`, `Task`, `ActivityLog`, `Notification`,
`RefreshToken` (see `backend/prisma/schema.prisma`). Indexes were added on every
column used in a `WHERE`/`ORDER BY` in the services layer: foreign keys
(`Project.createdById`, `Project.clientId`, `Task.projectId`,
`Task.assignedDeveloperId`, `ActivityLog.projectId/taskId`,
`Notification.recipientId`), the columns used for filtering
(`Task.status`, `Task.priority`, `Task.dueDate`, `Notification.isRead`), the
column used for feed ordering (`ActivityLog.createdAt`), and the unique lookup
column (`User.email`).

## WebSocket Decision

Socket.io was chosen over a raw `ws` WebSocket server for three reasons that matter
here: **rooms** (built-in, used heavily for `project:{id}` / `user:{id}` scoping),
automatic **reconnection** with backoff (important for the missed-event catch-up
flow), and a simple **auth middleware** hook (`io.use(...)`) to verify the JWT during
the handshake before any event is ever emitted to a socket.

## Background Job Decision

`node-cron` runs an in-process schedule (`* * * * *`, every minute) rather than a
separate worker/queue system, because at this scale a single Node process is enough
and it keeps the deployment simple — no Redis, no separate worker deploy. The trade-off
(documented as a limitation below) is that it doesn't scale past one backend instance
without a distributed lock.

## Local Setup

```bash
git clone <this-repo>
cd <this-repo>
cp .env.example .env
docker compose up -d              # starts Postgres

cd backend
cp ../.env.example .env           # backend reads its own .env
npm install
npx prisma migrate dev --name init
npx prisma db seed
npm run dev                       # http://localhost:4000

# in a second terminal
cd frontend
npm install
npm run dev                       # http://localhost:5173
```

## Seed Credentials

All seed accounts share the password: **`Password123!`**

| Role | Email |
|---|---|
| Admin | admin@example.com |
| Project Manager | pm1@example.com |
| Project Manager | pm2@example.com |
| Developer | developer1@example.com |
| Developer | developer2@example.com |
| Developer | developer3@example.com |
| Developer | developer4@example.com |

PM1 owns *Northwind Storefront Revamp* and *Acme Fleet Tracker*; PM2 owns
*Globex Patient Portal* — log in as each to see the ownership boundary enforced
(PM2 cannot open PM1's projects, and vice versa). Developer1–4 are spread across
those projects' tasks so you can confirm a developer only ever sees their own tasks.

## Tests

```bash
cd backend
docker compose up -d && npx prisma migrate dev && npx prisma db seed   # from repo root first
npm test
```

The suite (`backend/tests/authorization.test.ts`) runs against a real seeded
Postgres instance (not mocks) and checks: unauthenticated requests are rejected,
admin sees everything, a PM can access their own project but not another PM's,
a developer can access their own task but not another developer's (and can't
update its status), and a status change produces a persisted `ActivityLog` row.

## Build

```bash
cd backend && npm run build   # tsc -p tsconfig.json
cd frontend && npm run build  # tsc -b && vite build
```

## Environment Variables

See `.env.example` at the repo root. `DATABASE_URL`, `JWT_ACCESS_SECRET`,
`JWT_REFRESH_SECRET`, `ACCESS_TOKEN_EXPIRES_IN`, `REFRESH_TOKEN_EXPIRES_IN`,
`CLIENT_URL`, `PORT`, `COOKIE_SECURE` (set to `true` in production behind HTTPS).

## Known Limitations

This was intentionally built fast and kept simple, so a few things a fully
exhaustive version would include were traded off:

- **Frontend base URL is hardcoded** to `http://localhost:4000` in
  `frontend/src/api/client.ts` / `useSocket.ts` rather than read from a Vite env
  var — trivial to change for a different port/host.
- **Test coverage** covers the critical authorization/activity/notification paths
  (the highest-risk area) but not every endpoint or edge case from the full spec
  (e.g. refresh-token-rotation-under-concurrency, full CRUD validation matrix).
- **No production deployment configs** (Vercel/Render/etc. manifests) were written;
  the app is structured to deploy normally (stateless Express API + static Vite
  build) but the actual platform-specific files aren't included.
- **Admin dashboard** shows core stats and the live global feed, but doesn't include
  charts/graphs — numbers are shown as plain stat cards.
- **The overdue cron job** runs in-process; running multiple backend instances
  without a distributed lock could double-process the same task in the same tick
  (harmless here since the update is idempotent, but worth flagging).

### Hardest problem & how the real-time role-filtered feed works

The trickiest part was making sure Socket.io **room membership never doubles as
authorization**. A developer is placed into a project's room because they have
*some* task there, but that doesn't mean they should see *every* activity event in
that project (a PM's activity on another developer's task, for instance). The fix
was to stop broadcasting to rooms for activity events entirely and instead resolve
recipients explicitly server-side on every emit: always send to the admin global
room, always send to the owning PM's personal room, and only send to a task's
assigned developer's personal room — using `user:{id}` rooms as the actual
authorization boundary rather than `project:{id}` rooms. The missed-event catch-up
endpoint applies the exact same `buildActivityWhereForUser` logic that the initial
feed load uses, so a reconnecting client can never see something it wasn't already
entitled to. If I were to revisit this, I'd move that shared authorization
predicate into a single function used by both the REST and socket paths (right now
it's duplicated in spirit between `activityService.ts` and `sockets/index.ts`), and
add a small pub/sub layer (e.g. Redis) so this same room/notification logic scales
horizontally across multiple backend instances instead of living in one process's
in-memory presence map.
