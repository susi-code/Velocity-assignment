import { Router } from "express";
import { authenticate, authorizeRoles } from "../middleware/auth";
import { authorizeProjectAccess } from "../middleware/resourceAuth";
import * as projectController from "../controllers/projectController";
import taskRoutes from "./taskRoutes";

const router = Router();

router.use(authenticate);

router.get("/", projectController.listProjects);
router.post("/", authorizeRoles("ADMIN", "PROJECT_MANAGER"), projectController.createProject);

router.get("/:id", authorizeProjectAccess, projectController.getProject);
router.patch(
  "/:id",
  authorizeRoles("ADMIN", "PROJECT_MANAGER"),
  authorizeProjectAccess,
  projectController.updateProject
);
router.delete(
  "/:id",
  authorizeRoles("ADMIN", "PROJECT_MANAGER"),
  authorizeProjectAccess,
  projectController.deleteProject
);

// Nested task routes: /api/projects/:projectId/tasks
router.use("/:projectId/tasks", taskRoutes);

export default router;
