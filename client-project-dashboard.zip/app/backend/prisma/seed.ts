import { PrismaClient, Priority, TaskStatus } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

const SEED_PASSWORD = "Password123!";

async function main() {
  console.log("Seeding database...");

  const passwordHash = await bcrypt.hash(SEED_PASSWORD, 10);

  const admin = await prisma.user.create({
    data: { name: "Alice Admin", email: "admin@example.com", passwordHash, role: "ADMIN" },
  });

  const pm1 = await prisma.user.create({
    data: { name: "Priya Manager", email: "pm1@example.com", passwordHash, role: "PROJECT_MANAGER" },
  });
  const pm2 = await prisma.user.create({
    data: { name: "Paul Manager", email: "pm2@example.com", passwordHash, role: "PROJECT_MANAGER" },
  });

  const dev1 = await prisma.user.create({
    data: { name: "Ravi Dev", email: "developer1@example.com", passwordHash, role: "DEVELOPER" },
  });
  const dev2 = await prisma.user.create({
    data: { name: "Dana Dev", email: "developer2@example.com", passwordHash, role: "DEVELOPER" },
  });
  const dev3 = await prisma.user.create({
    data: { name: "Diego Dev", email: "developer3@example.com", passwordHash, role: "DEVELOPER" },
  });
  const dev4 = await prisma.user.create({
    data: { name: "Dara Dev", email: "developer4@example.com", passwordHash, role: "DEVELOPER" },
  });

  const clientA = await prisma.client.create({
    data: { name: "Northwind Retail", email: "contact@northwind.example", company: "Northwind Retail Inc." },
  });
  const clientB = await prisma.client.create({
    data: { name: "Acme Logistics", email: "ops@acme.example", company: "Acme Logistics LLC" },
  });
  const clientC = await prisma.client.create({
    data: { name: "Globex Health", email: "it@globex.example", company: "Globex Health Systems" },
  });

  // PM1 owns Project A and Project B; PM2 owns Project C (see spec section 25)
  const projectA = await prisma.project.create({
    data: {
      name: "Northwind Storefront Revamp",
      description: "Rebuild the e-commerce storefront with a new checkout flow.",
      clientId: clientA.id,
      createdById: pm1.id,
    },
  });
  const projectB = await prisma.project.create({
    data: {
      name: "Acme Fleet Tracker",
      description: "Real-time vehicle tracking dashboard for the logistics fleet.",
      clientId: clientB.id,
      createdById: pm1.id,
    },
  });
  const projectC = await prisma.project.create({
    data: {
      name: "Globex Patient Portal",
      description: "Secure patient-facing portal for appointment scheduling.",
      clientId: clientC.id,
      createdById: pm2.id,
    },
  });

  const now = Date.now();
  const days = (n: number) => new Date(now + n * 24 * 60 * 60 * 1000);

  type TaskSeed = {
    title: string;
    description: string;
    assignedDeveloperId: string;
    status: TaskStatus;
    priority: Priority;
    dueDate: Date;
  };

  const tasksA: TaskSeed[] = [
    { title: "Build product listing page", description: "Grid + filters for catalog browsing.", assignedDeveloperId: dev1.id, status: "IN_PROGRESS", priority: "HIGH", dueDate: days(5) },
    { title: "Implement checkout API", description: "Payment intent + order creation endpoints.", assignedDeveloperId: dev1.id, status: "TODO", priority: "CRITICAL", dueDate: days(3) },
    { title: "Cart persistence", description: "Persist cart contents across sessions.", assignedDeveloperId: dev2.id, status: "IN_REVIEW", priority: "MEDIUM", dueDate: days(7) },
    { title: "Fix mobile nav overlap", description: "Header nav overlaps content on small screens.", assignedDeveloperId: dev2.id, status: "TODO", priority: "LOW", dueDate: days(-2) },
    { title: "Add order confirmation email", description: "Send transactional email after checkout.", assignedDeveloperId: dev1.id, status: "DONE", priority: "MEDIUM", dueDate: days(-5) },
  ];

  const tasksB: TaskSeed[] = [
    { title: "Live map socket integration", description: "Stream vehicle coordinates over WebSocket.", assignedDeveloperId: dev2.id, status: "IN_PROGRESS", priority: "CRITICAL", dueDate: days(4) },
    { title: "Geofence alerting", description: "Notify dispatch when a vehicle leaves its zone.", assignedDeveloperId: dev1.id, status: "TODO", priority: "HIGH", dueDate: days(10) },
    { title: "Driver shift reports", description: "Daily summary of driver hours and stops.", assignedDeveloperId: dev2.id, status: "TODO", priority: "LOW", dueDate: days(14) },
    { title: "Fix timestamp timezone bug", description: "Timestamps display in UTC instead of local time.", assignedDeveloperId: dev1.id, status: "TODO", priority: "MEDIUM", dueDate: days(-1) },
    { title: "Fleet dashboard filters", description: "Filter vehicles by status and region.", assignedDeveloperId: dev2.id, status: "IN_REVIEW", priority: "MEDIUM", dueDate: days(6) },
  ];

  const tasksC: TaskSeed[] = [
    { title: "Appointment booking flow", description: "Multi-step booking wizard for patients.", assignedDeveloperId: dev3.id, status: "IN_PROGRESS", priority: "CRITICAL", dueDate: days(5) },
    { title: "HIPAA audit logging", description: "Log all access to patient records.", assignedDeveloperId: dev4.id, status: "TODO", priority: "HIGH", dueDate: days(8) },
    { title: "Provider availability calendar", description: "Sync provider calendars for booking slots.", assignedDeveloperId: dev3.id, status: "TODO", priority: "MEDIUM", dueDate: days(12) },
    { title: "Patient reminder SMS", description: "Send SMS reminders 24h before appointments.", assignedDeveloperId: dev4.id, status: "DONE", priority: "LOW", dueDate: days(-6) },
    { title: "Insurance verification form", description: "Collect and validate insurance details.", assignedDeveloperId: dev3.id, status: "TODO", priority: "HIGH", dueDate: days(9) },
  ];

  async function seedTasks(projectId: string, seeds: TaskSeed[]) {
    const created = [];
    for (const s of seeds) {
      const task = await prisma.task.create({ data: { ...s, projectId } });
      created.push(task);
    }
    return created;
  }

  const createdA = await seedTasks(projectA.id, tasksA);
  const createdB = await seedTasks(projectB.id, tasksB);
  const createdC = await seedTasks(projectC.id, tasksC);

  // Pre-existing activity log entries so the feed is never empty.
  const activityData = [
    { projectId: projectA.id, taskId: createdA[0].id, userId: pm1.id, action: "TASK_CREATED", newValue: createdA[0].title },
    { projectId: projectA.id, taskId: createdA[2].id, userId: dev2.id, action: "STATUS_CHANGED", oldValue: "IN_PROGRESS", newValue: "IN_REVIEW" },
    { projectId: projectA.id, taskId: createdA[4].id, userId: dev1.id, action: "STATUS_CHANGED", oldValue: "IN_REVIEW", newValue: "DONE" },
    { projectId: projectB.id, taskId: createdB[0].id, userId: dev2.id, action: "STATUS_CHANGED", oldValue: "TODO", newValue: "IN_PROGRESS" },
    { projectId: projectB.id, taskId: createdB[4].id, userId: dev2.id, action: "STATUS_CHANGED", oldValue: "IN_PROGRESS", newValue: "IN_REVIEW" },
    { projectId: projectC.id, taskId: createdC[0].id, userId: pm2.id, action: "TASK_CREATED", newValue: createdC[0].title },
    { projectId: projectC.id, taskId: createdC[3].id, userId: dev4.id, action: "STATUS_CHANGED", oldValue: "IN_REVIEW", newValue: "DONE" },
  ];
  for (const a of activityData) {
    await prisma.activityLog.create({ data: a });
  }

  // Sample notifications
  await prisma.notification.create({
    data: {
      recipientId: dev1.id,
      projectId: projectA.id,
      taskId: createdA[1].id,
      type: "TASK_ASSIGNED",
      message: `You were assigned Task: ${createdA[1].title}`,
    },
  });
  await prisma.notification.create({
    data: {
      recipientId: pm1.id,
      projectId: projectA.id,
      taskId: createdA[2].id,
      type: "TASK_IN_REVIEW",
      message: `Task "${createdA[2].title}" was moved to In Review`,
    },
  });
  await prisma.notification.create({
    data: {
      recipientId: pm2.id,
      projectId: projectC.id,
      taskId: createdC[3].id,
      type: "GENERAL",
      message: `Task "${createdC[3].title}" was completed`,
      isRead: true,
    },
  });

  console.log("Seed complete.");
  console.log("---------------------------------------------");
  console.log(`All seed accounts use the password: ${SEED_PASSWORD}`);
  console.log("admin@example.com / pm1@example.com / pm2@example.com");
  console.log("developer1@example.com .. developer4@example.com");
  console.log("---------------------------------------------");
  console.log(`Admin: ${admin.email}`);
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
