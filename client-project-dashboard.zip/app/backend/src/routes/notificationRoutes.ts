import { Router } from "express";
import { authenticate } from "../middleware/auth";
import { asyncHandler } from "../middleware/errorHandler";
import * as notificationService from "../services/notificationService";
import { ApiError } from "../utils/ApiError";

const router = Router();
router.use(authenticate);

router.get(
  "/",
  asyncHandler(async (req, res) => {
    const notifications = await notificationService.listNotifications(req.user!.id);
    res.json({ success: true, data: notifications });
  })
);

router.patch(
  "/:id/read",
  asyncHandler(async (req, res) => {
    const updated = await notificationService.markRead(req.user!.id, req.params.id);
    if (!updated) throw ApiError.notFound("Notification not found");
    res.json({ success: true, data: updated });
  })
);

router.patch(
  "/read-all",
  asyncHandler(async (req, res) => {
    await notificationService.markAllRead(req.user!.id);
    res.json({ success: true, data: null });
  })
);

export default router;
