import { Router } from "express";
import { authenticate, authorizeRoles } from "../middleware/auth";
import { authorizeTaskAccess } from "../middleware/resourceAuth";
import * as taskController from "../controllers/taskController";

const router = Router();

router.use(authenticate);

router.get("/mine", taskController.listMyTasks);

router.get("/:id", authorizeTaskAccess, taskController.getTask);
router.patch("/:id", authorizeRoles("ADMIN", "PROJECT_MANAGER"), authorizeTaskAccess, taskController.updateTask);
router.delete("/:id", authorizeRoles("ADMIN", "PROJECT_MANAGER"), authorizeTaskAccess, taskController.deleteTask);
router.patch("/:id/status", authorizeTaskAccess, taskController.updateTaskStatus);

export default router;
