import { Request, Response } from "express";
import { asyncHandler } from "../middleware/errorHandler";
import { createProjectSchema, updateProjectSchema } from "../validators/schemas";
import * as projectService from "../services/projectService";
import { ApiError } from "../utils/ApiError";

export const listProjects = asyncHandler(async (req: Request, res: Response) => {
  const projects = await projectService.listProjectsForUser(req.user!);
  res.json({ success: true, data: projects });
});

export const getProject = asyncHandler(async (req: Request, res: Response) => {
  // authorizeProjectAccess middleware already verified ownership and set req.project
  const project = await projectService.getProjectDetail(req.project!.id);
  res.json({ success: true, data: project });
});

export const createProject = asyncHandler(async (req: Request, res: Response) => {
  const body = createProjectSchema.parse(req.body);
  const project = await projectService.createProject(req.user!, body);
  res.status(201).json({ success: true, data: project });
});

export const updateProject = asyncHandler(async (req: Request, res: Response) => {
  const body = updateProjectSchema.parse(req.body);
  const project = await projectService.updateProject(req.project!.id, body);
  res.json({ success: true, data: project });
});

export const deleteProject = asyncHandler(async (req: Request, res: Response) => {
  if (req.user!.role !== "ADMIN" && req.project!.createdById !== req.user!.id) {
    throw ApiError.forbidden();
  }
  await projectService.deleteProject(req.project!.id);
  res.json({ success: true, data: null });
});
