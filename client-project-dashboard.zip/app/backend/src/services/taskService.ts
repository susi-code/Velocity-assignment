import { Prisma, Role, TaskStatus } from "@prisma/client";
import { prisma } from "../config/prisma";
import { ApiError } from "../utils/ApiError";
import { logActivity } from "./activityService";
import { createNotification, pushNotificationRealtime } from "./notificationService";
import { emitActivity, emitTaskUpdated } from "../sockets";

export interface TaskFilters {
  status?: TaskStatus;
  priority?: string;
  dueDateFrom?: Date;
  dueDateTo?: Date;
}

/** Lists tasks for a project, applying role-based visibility THEN the requested filters. */
export async function listTasksForProject(
  user: { id: string; role: Role },
  projectId: string,
  filters: TaskFilters
) {
  const where: Prisma.TaskWhereInput = { projectId };

  // Role-based visibility is applied first and cannot be bypassed by filters.
  if (user.role === "DEVELOPER") {
    where.assignedDeveloperId = user.id;
  }

  if (filters.status) where.status = filters.status;
  if (filters.priority) where.priority = filters.priority as any;
  if (filters.dueDateFrom || filters.dueDateTo) {
    where.dueDate = {
      ...(filters.dueDateFrom ? { gte: filters.dueDateFrom } : {}),
      ...(filters.dueDateTo ? { lte: filters.dueDateTo } : {}),
    };
  }

  return prisma.task.findMany({
    where,
    include: { assignedDeveloper: { select: { id: true, name: true } } },
    orderBy: [{ priority: "desc" }, { dueDate: "asc" }],
  });
}

/** Developer's own task list across all projects, sorted by priority then due date. */
export async function listMyTasks(userId: string) {
  const priorityOrder: Record<string, number> = { CRITICAL: 0, HIGH: 1, MEDIUM: 2, LOW: 3 };
  const tasks = await prisma.task.findMany({
    where: { assignedDeveloperId: userId },
    include: { project: { select: { id: true, name: true } } },
  });
  return tasks.sort((a, b) => {
    const p = priorityOrder[a.priority] - priorityOrder[b.priority];
    if (p !== 0) return p;
    return a.dueDate.getTime() - b.dueDate.getTime();
  });
}

export async function createTask(
  creator: { id: string },
  projectId: string,
  data: { title: string; description: string; assignedDeveloperId?: string | null; priority: string; dueDate: Date }
) {
  const task = await prisma.$transaction(async (tx) => {
    const created = await tx.task.create({
      data: { ...data, projectId, priority: data.priority as any },
    });

    await logActivity(tx, {
      projectId,
      taskId: created.id,
      userId: creator.id,
      action: "TASK_CREATED",
      newValue: created.title,
    });

    if (data.assignedDeveloperId) {
      const notif = await createNotification(tx, {
        recipientId: data.assignedDeveloperId,
        projectId,
        taskId: created.id,
        type: "TASK_ASSIGNED",
        message: `You were assigned Task: ${created.title}`,
      });
      return { created, notif };
    }
    return { created, notif: null };
  });

  if (task.notif) {
    await pushNotificationRealtime(task.notif.recipientId, task.notif);
  }
  emitTaskUpdated(task.created);

  return task.created;
}

export async function updateTaskFields(
  taskId: string,
  data: Partial<{ title: string; description: string; assignedDeveloperId: string | null; priority: string; dueDate: Date }>
) {
  const previous = await prisma.task.findUnique({ where: { id: taskId } });
  if (!previous) throw ApiError.notFound("Task not found");

  const updated = await prisma.$transaction(async (tx) => {
    const task = await tx.task.update({ where: { id: taskId }, data: data as any });

    if (data.assignedDeveloperId && data.assignedDeveloperId !== previous.assignedDeveloperId) {
      const notif = await createNotification(tx, {
        recipientId: data.assignedDeveloperId,
        projectId: task.projectId,
        taskId: task.id,
        type: "TASK_ASSIGNED",
        message: `You were assigned Task: ${task.title}`,
      });
      return { task, notif };
    }
    return { task, notif: null };
  });

  if (updated.notif) {
    await pushNotificationRealtime(updated.notif.recipientId, updated.notif);
  }
  emitTaskUpdated(updated.task);
  return updated.task;
}

export async function deleteTask(taskId: string) {
  await prisma.notification.deleteMany({ where: { taskId } });
  await prisma.activityLog.deleteMany({ where: { taskId } });
  await prisma.task.delete({ where: { id: taskId } });
}

/**
 * Full transactional status-update flow (see spec section 29):
 * validate -> update task -> log activity -> notify owning PM on IN_REVIEW ->
 * commit -> emit socket events. If the transaction fails, nothing is emitted.
 */
export async function updateTaskStatus(
  actor: { id: string; role: Role },
  taskId: string,
  newStatus: TaskStatus
) {
  const result = await prisma.$transaction(async (tx) => {
    const task = await tx.task.findUnique({ where: { id: taskId }, include: { project: true } });
    if (!task) throw ApiError.notFound("Task not found");

    // Ownership re-checked here defensively even though route middleware already checked it.
    if (actor.role === "DEVELOPER" && task.assignedDeveloperId !== actor.id) {
      throw ApiError.forbidden();
    }
    if (actor.role === "PROJECT_MANAGER" && task.project.createdById !== actor.id) {
      throw ApiError.forbidden();
    }

    const oldStatus = task.status;
    const updatedTask = await tx.task.update({ where: { id: taskId }, data: { status: newStatus } });

    await logActivity(tx, {
      projectId: task.projectId,
      taskId: task.id,
      userId: actor.id,
      action: "STATUS_CHANGED",
      oldValue: oldStatus,
      newValue: newStatus,
    });

    let notif = null;
    if (newStatus === "IN_REVIEW") {
      notif = await createNotification(tx, {
        recipientId: task.project.createdById,
        projectId: task.projectId,
        taskId: task.id,
        type: "TASK_IN_REVIEW",
        message: `Task "${task.title}" was moved to In Review`,
      });
    }

    const activity = await tx.activityLog.findFirst({
      where: { taskId: task.id, action: "STATUS_CHANGED" },
      orderBy: { createdAt: "desc" },
    });

    return { updatedTask, notif, activity };
  });

  // Everything below only runs if the transaction committed successfully.
  if (result.activity) {
    await emitActivity({
      id: result.activity.id,
      projectId: result.activity.projectId,
      taskId: result.activity.taskId,
      userId: result.activity.userId,
      action: result.activity.action,
      oldValue: result.activity.oldValue,
      newValue: result.activity.newValue,
      createdAt: result.activity.createdAt,
    });
  }
  emitTaskUpdated(result.updatedTask);
  if (result.notif) {
    await pushNotificationRealtime(result.notif.recipientId, result.notif);
  }

  return result.updatedTask;
}
