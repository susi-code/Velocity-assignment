import { Request, Response } from "express";
import { asyncHandler } from "../middleware/errorHandler";
import {
  createTaskSchema,
  taskFilterQuerySchema,
  updateTaskSchema,
  updateTaskStatusSchema,
} from "../validators/schemas";
import * as taskService from "../services/taskService";
import { ApiError } from "../utils/ApiError";

export const listTasksForProject = asyncHandler(async (req: Request, res: Response) => {
  const filters = taskFilterQuerySchema.parse(req.query);
  const tasks = await taskService.listTasksForProject(req.user!, req.project!.id, filters);
  res.json({ success: true, data: tasks });
});

export const listMyTasks = asyncHandler(async (req: Request, res: Response) => {
  const tasks = await taskService.listMyTasks(req.user!.id);
  res.json({ success: true, data: tasks });
});

export const getTask = asyncHandler(async (req: Request, res: Response) => {
  res.json({ success: true, data: req.task });
});

export const createTask = asyncHandler(async (req: Request, res: Response) => {
  if (req.user!.role !== "ADMIN" && req.user!.role !== "PROJECT_MANAGER") {
    throw ApiError.forbidden();
  }
  const body = createTaskSchema.parse(req.body);
  const task = await taskService.createTask(req.user!, req.project!.id, body);
  res.status(201).json({ success: true, data: task });
});

export const updateTask = asyncHandler(async (req: Request, res: Response) => {
  // Developers may never reach here for field updates (route restricts to ADMIN/PM),
  // but we double check to avoid relying only on route-level checks.
  if (req.user!.role === "DEVELOPER") throw ApiError.forbidden();
  const body = updateTaskSchema.parse(req.body);
  const task = await taskService.updateTaskFields(req.task!.id, body);
  res.json({ success: true, data: task });
});

export const deleteTask = asyncHandler(async (req: Request, res: Response) => {
  if (req.user!.role === "DEVELOPER") throw ApiError.forbidden();
  await taskService.deleteTask(req.task!.id);
  res.json({ success: true, data: null });
});

export const updateTaskStatus = asyncHandler(async (req: Request, res: Response) => {
  const { status } = updateTaskStatusSchema.parse(req.body);

  // A developer may only change status on their OWN task (already enforced by
  // authorizeTaskAccess), and may ONLY change status, never other fields.
  const task = await taskService.updateTaskStatus(req.user!, req.task!.id, status);
  res.json({ success: true, data: task });
});
