import { Router } from "express";
import { authorizeRoles } from "../middleware/auth";
import { authorizeProjectAccess } from "../middleware/resourceAuth";
import * as taskController from "../controllers/taskController";

// mergeParams so :projectId from the parent router is available here
const router = Router({ mergeParams: true });

router.get("/", authorizeProjectAccess, taskController.listTasksForProject);
router.post("/", authorizeRoles("ADMIN", "PROJECT_MANAGER"), authorizeProjectAccess, taskController.createTask);

export default router;
