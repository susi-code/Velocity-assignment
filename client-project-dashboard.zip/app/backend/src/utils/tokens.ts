import jwt from "jsonwebtoken";
import crypto from "crypto";
import { Role } from "@prisma/client";
import { env } from "../config/env";

export interface AccessTokenPayload {
  sub: string;
  role: Role;
  email: string;
}

export function signAccessToken(payload: AccessTokenPayload): string {
  return jwt.sign(payload, env.jwtAccessSecret, { expiresIn: env.accessTokenExpiresIn as any });
}

export function verifyAccessToken(token: string): AccessTokenPayload {
  return jwt.verify(token, env.jwtAccessSecret) as AccessTokenPayload;
}

export interface RefreshTokenPayload {
  sub: string;
  jti: string;
}

export function signRefreshToken(userId: string, jti: string): string {
  return jwt.sign({ sub: userId, jti }, env.jwtRefreshSecret, {
    expiresIn: env.refreshTokenExpiresIn as any,
  });
}

export function verifyRefreshToken(token: string): RefreshTokenPayload {
  return jwt.verify(token, env.jwtRefreshSecret) as RefreshTokenPayload;
}

export function hashToken(token: string): string {
  return crypto.createHash("sha256").update(token).digest("hex");
}

export function newJti(): string {
  return crypto.randomUUID();
}

export function refreshExpiryDate(): Date {
  // Parse simple formats like "7d", "15m", "1h"
  const match = env.refreshTokenExpiresIn.match(/^(\d+)([smhd])$/);
  const now = new Date();
  if (!match) {
    now.setDate(now.getDate() + 7);
    return now;
  }
  const amount = Number(match[1]);
  const unit = match[2];
  const msPerUnit: Record<string, number> = { s: 1000, m: 60000, h: 3600000, d: 86400000 };
  return new Date(now.getTime() + amount * msPerUnit[unit]);
}
