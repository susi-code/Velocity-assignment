import { useEffect, useRef } from "react";
import { io, Socket } from "socket.io-client";
import { useAuthStore } from "../store/authStore";

export interface SocketHandlers {
  onActivityNew?: (activity: unknown) => void;
  onTaskUpdated?: (task: unknown) => void;
  onNotificationNew?: (notification: unknown) => void;
  onNotificationCount?: (payload: { count: number }) => void;
  onPresenceCount?: (payload: { count: number }) => void;
  onPresenceOnline?: (payload: { userId: string }) => void;
  onPresenceOffline?: (payload: { userId: string }) => void;
}

/**
 * Establishes a single Socket.io connection authenticated with the current
 * access token. Reconnects automatically if the token changes (e.g. after
 * a silent refresh). No polling anywhere.
 */
export function useSocket(handlers: SocketHandlers) {
  const accessToken = useAuthStore((s) => s.accessToken);
  const socketRef = useRef<Socket | null>(null);
  const handlersRef = useRef(handlers);
  handlersRef.current = handlers;

  useEffect(() => {
    if (!accessToken) return;

    const socket = io("http://localhost:4000", {
      auth: { token: accessToken },
      transports: ["websocket"],
    });
    socketRef.current = socket;

    socket.on("activity:new", (payload) => handlersRef.current.onActivityNew?.(payload));
    socket.on("task:updated", (payload) => handlersRef.current.onTaskUpdated?.(payload));
    socket.on("notification:new", (payload) => handlersRef.current.onNotificationNew?.(payload));
    socket.on("notification:count", (payload) => handlersRef.current.onNotificationCount?.(payload));
    socket.on("presence:count", (payload) => handlersRef.current.onPresenceCount?.(payload));
    socket.on("presence:user-online", (payload) => handlersRef.current.onPresenceOnline?.(payload));
    socket.on("presence:user-offline", (payload) => handlersRef.current.onPresenceOffline?.(payload));

    return () => {
      socket.disconnect();
    };
  }, [accessToken]);

  return socketRef;
}
