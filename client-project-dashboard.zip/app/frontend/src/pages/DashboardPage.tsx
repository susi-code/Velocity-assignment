import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { useAuthStore } from "../store/authStore";
import { statsApi, projectsApi, tasksApi } from "../api/endpoints";
import { Card, StatCard } from "../components/Card";
import { ActivityTimeline } from "../components/ActivityTimeline";
import { useActivityFeed } from "../hooks/useActivityFeed";
import { useSocket } from "../hooks/useSocket";
import { PriorityBadge, StatusBadge } from "../components/Badges";
import { Link } from "react-router-dom";

export function DashboardPage() {
  const user = useAuthStore((s) => s.user)!;
  if (user.role === "ADMIN") return <AdminDashboard />;
  if (user.role === "PROJECT_MANAGER") return <PmDashboard />;
  return <DeveloperDashboard />;
}

function AdminDashboard() {
  const [onlineCount, setOnlineCount] = useState<number | null>(null);
  const { data } = useQuery({ queryKey: ["stats-admin"], queryFn: () => statsApi.admin().then((r) => r.data.data) });
  const activities = useActivityFeed();

  useSocket({ onPresenceCount: (p) => setOnlineCount(p.count) });

  const stats = data;
  return (
    <div className="space-y-6">
      <h1 className="text-xl font-bold text-slate-800">Admin Dashboard</h1>

      <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-5">
        <StatCard label="Total Projects" value={stats?.totalProjects ?? "—"} />
        <StatCard label="Total Tasks" value={stats?.totalTasks ?? "—"} />
        <StatCard label="Overdue Tasks" value={stats?.overdueCount ?? "—"} accent="text-red-600" />
        <StatCard label="Online Now" value={onlineCount ?? stats?.onlineUsers ?? "—"} accent="text-emerald-600" />
        <StatCard
          label="In Review"
          value={stats?.tasksByStatus.find((s) => s.status === "IN_REVIEW")?.count ?? 0}
          accent="text-amber-600"
        />
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card title="Tasks by Status">
          <ul className="space-y-2">
            {stats?.tasksByStatus.map((s) => (
              <li key={s.status} className="flex items-center justify-between text-sm">
                <StatusBadge status={s.status as any} />
                <span className="font-semibold text-slate-700">{s.count}</span>
              </li>
            ))}
          </ul>
        </Card>
        <Card title="Global Activity Feed (live)">
          <ActivityTimeline activities={activities} />
        </Card>
      </div>
    </div>
  );
}

function PmDashboard() {
  const { data: projects } = useQuery({
    queryKey: ["projects"],
    queryFn: () => projectsApi.list().then((r) => r.data.data),
  });
  const activities = useActivityFeed();

  return (
    <div className="space-y-6">
      <h1 className="text-xl font-bold text-slate-800">My Projects</h1>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card title="Your Projects">
          <ul className="space-y-3">
            {projects?.map((p) => (
              <li key={p.id}>
                <Link to={`/projects/${p.id}`} className="block rounded-md p-2 hover:bg-slate-50">
                  <p className="text-sm font-semibold text-slate-800">{p.name}</p>
                  <p className="text-xs text-slate-500">
                    {p.client?.company} · {p._count?.tasks ?? 0} tasks
                  </p>
                </Link>
              </li>
            ))}
            {projects?.length === 0 && <p className="text-sm text-slate-400">No projects yet.</p>}
          </ul>
        </Card>
        <Card title="Recent Activity (your projects)">
          <ActivityTimeline activities={activities} />
        </Card>
      </div>
    </div>
  );
}

function DeveloperDashboard() {
  const { data: tasks } = useQuery({ queryKey: ["my-tasks"], queryFn: () => tasksApi.mine().then((r) => r.data.data) });
  const activities = useActivityFeed();

  return (
    <div className="space-y-6">
      <h1 className="text-xl font-bold text-slate-800">My Tasks</h1>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card title="Assigned to me (sorted by priority, then due date)">
          <ul className="space-y-3">
            {tasks?.map((t) => (
              <li key={t.id} className="rounded-md border border-slate-100 p-3">
                <div className="flex items-center justify-between">
                  <p className="text-sm font-semibold text-slate-800">{t.title}</p>
                  <PriorityBadge priority={t.priority} />
                </div>
                <div className="mt-2 flex items-center justify-between">
                  <StatusBadge status={t.status} />
                  <span className="text-xs text-slate-400">Due {new Date(t.dueDate).toLocaleDateString()}</span>
                </div>
              </li>
            ))}
            {tasks?.length === 0 && <p className="text-sm text-slate-400">No tasks assigned.</p>}
          </ul>
        </Card>
        <Card title="Activity on your tasks">
          <ActivityTimeline activities={activities} />
        </Card>
      </div>
    </div>
  );
}
