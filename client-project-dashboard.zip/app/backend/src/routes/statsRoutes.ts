import { Router } from "express";
import { authenticate, authorizeRoles } from "../middleware/auth";
import { asyncHandler } from "../middleware/errorHandler";
import { prisma } from "../config/prisma";
import { getOnlineCount } from "../sockets";

const router = Router();
router.use(authenticate);

router.get(
  "/admin",
  authorizeRoles("ADMIN"),
  asyncHandler(async (_req, res) => {
    const [totalProjects, totalTasks, byStatus, overdueCount] = await Promise.all([
      prisma.project.count(),
      prisma.task.count(),
      prisma.task.groupBy({ by: ["status"], _count: true }),
      prisma.task.count({ where: { status: "OVERDUE" } }),
    ]);

    res.json({
      success: true,
      data: {
        totalProjects,
        totalTasks,
        tasksByStatus: byStatus.map((s) => ({ status: s.status, count: s._count })),
        overdueCount,
        onlineUsers: getOnlineCount(),
      },
    });
  })
);

export default router;
