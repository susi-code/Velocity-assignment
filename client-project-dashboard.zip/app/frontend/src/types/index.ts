export type Role = "ADMIN" | "PROJECT_MANAGER" | "DEVELOPER";
export type TaskStatus = "TODO" | "IN_PROGRESS" | "IN_REVIEW" | "DONE" | "OVERDUE";
export type Priority = "LOW" | "MEDIUM" | "HIGH" | "CRITICAL";

export interface User {
  id: string;
  name: string;
  email: string;
  role: Role;
}

export interface Client {
  id: string;
  name: string;
  email: string;
  company: string;
}

export interface Project {
  id: string;
  name: string;
  description: string;
  clientId: string;
  createdById: string;
  createdAt: string;
  client?: Client;
  createdBy?: { id: string; name: string };
  tasks?: Task[];
  _count?: { tasks: number };
}

export interface Task {
  id: string;
  projectId: string;
  title: string;
  description: string;
  assignedDeveloperId: string | null;
  status: TaskStatus;
  priority: Priority;
  dueDate: string;
  createdAt: string;
  assignedDeveloper?: { id: string; name: string } | null;
  project?: { id: string; name: string };
}

export interface ActivityLog {
  id: string;
  projectId: string;
  taskId: string | null;
  userId: string;
  action: string;
  oldValue: string | null;
  newValue: string | null;
  createdAt: string;
  user?: { id: string; name: string };
  task?: { id: string; title: string } | null;
  project?: { id: string; name: string };
}

export interface Notification {
  id: string;
  recipientId: string;
  projectId: string | null;
  taskId: string | null;
  type: "TASK_ASSIGNED" | "TASK_IN_REVIEW" | "TASK_OVERDUE" | "GENERAL";
  message: string;
  isRead: boolean;
  createdAt: string;
}

export interface ApiSuccess<T> {
  success: true;
  data: T;
}

export interface ApiFailure {
  success: false;
  error: { code: string; message: string; details?: unknown };
}
