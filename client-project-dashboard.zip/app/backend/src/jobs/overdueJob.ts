import cron from "node-cron";
import { prisma } from "../config/prisma";
import { logActivity } from "../services/activityService";
import { emitActivity, emitTaskUpdated } from "../sockets";

/**
 * Runs every minute. Finds tasks whose dueDate has passed and whose status
 * is not DONE (and not already OVERDUE), flips them to OVERDUE, logs activity,
 * and emits a real-time update. This never runs on page load - only on this schedule.
 */
export function startOverdueJob() {
  cron.schedule("* * * * *", async () => {
    try {
      const now = new Date();
      const dueTasks = await prisma.task.findMany({
        where: {
          dueDate: { lt: now },
          status: { notIn: ["DONE", "OVERDUE"] },
        },
      });

      for (const task of dueTasks) {
        const result = await prisma.$transaction(async (tx) => {
          const updated = await tx.task.update({
            where: { id: task.id },
            data: { status: "OVERDUE" },
          });

          // ActivityLog.userId is a required FK to User. This is a system-triggered
          // change, so attribute it to the assigned developer if there is one,
          // otherwise to the project's owning PM.
          let attributedUserId = task.assignedDeveloperId;
          if (!attributedUserId) {
            const project = await tx.project.findUnique({ where: { id: task.projectId } });
            attributedUserId = project!.createdById;
          }

          const activity = await logActivity(tx, {
            projectId: task.projectId,
            taskId: task.id,
            userId: attributedUserId,
            action: "TASK_OVERDUE",
            oldValue: task.status,
            newValue: "OVERDUE",
          });
          return { updated, activity };
        });

        await emitActivity({
          id: result.activity.id,
          projectId: result.activity.projectId,
          taskId: result.activity.taskId,
          userId: result.activity.userId,
          action: result.activity.action,
          oldValue: result.activity.oldValue,
          newValue: result.activity.newValue,
          createdAt: result.activity.createdAt,
        });
        emitTaskUpdated(result.updated);
      }

      if (dueTasks.length > 0) {
        console.log(`[overdueJob] Marked ${dueTasks.length} task(s) as OVERDUE`);
      }
    } catch (err) {
      console.error("[overdueJob] Failed to process overdue tasks:", err);
    }
  });
}
