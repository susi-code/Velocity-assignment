import { useParams, useSearchParams } from "react-router-dom";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { projectsApi, tasksApi, usersApi } from "../api/endpoints";
import { useAuthStore } from "../store/authStore";
import { Card } from "../components/Card";
import { PriorityBadge, StatusBadge } from "../components/Badges";
import { Task, TaskStatus } from "../types";
import { useSocket } from "../hooks/useSocket";
import { extractErrorMessage } from "../api/client";

const STATUS_OPTIONS: TaskStatus[] = ["TODO", "IN_PROGRESS", "IN_REVIEW", "DONE", "OVERDUE"];
const PRIORITY_OPTIONS = ["LOW", "MEDIUM", "HIGH", "CRITICAL"];

export function ProjectDetailPage() {
  const { id } = useParams<{ id: string }>();
  const user = useAuthStore((s) => s.user)!;
  const queryClient = useQueryClient();
  const [searchParams, setSearchParams] = useSearchParams();
  const [showTaskForm, setShowTaskForm] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const status = searchParams.get("status") ?? "";
  const priority = searchParams.get("priority") ?? "";

  const { data: project } = useQuery({
    queryKey: ["project", id],
    queryFn: () => projectsApi.get(id!).then((r) => r.data.data),
  });

  const { data: tasks, isLoading: tasksLoading } = useQuery({
    queryKey: ["tasks", id, status, priority],
    queryFn: () =>
      tasksApi
        .listForProject(id!, { status: status || undefined, priority: priority || undefined })
        .then((r) => r.data.data),
    enabled: !!id,
  });

  const { data: developers } = useQuery({
    queryKey: ["developers"],
    queryFn: () => usersApi.developers().then((r) => r.data.data),
    enabled: showTaskForm,
  });

  useSocket({
    onTaskUpdated: () => {
      queryClient.invalidateQueries({ queryKey: ["tasks", id] });
    },
  });

  function updateFilter(key: string, value: string) {
    const next = new URLSearchParams(searchParams);
    if (value) next.set(key, value);
    else next.delete(key);
    setSearchParams(next);
  }

  const [taskForm, setTaskForm] = useState({
    title: "",
    description: "",
    assignedDeveloperId: "",
    priority: "MEDIUM",
    dueDate: "",
  });

  const createTask = useMutation({
    mutationFn: () =>
      tasksApi.create(id!, {
        title: taskForm.title,
        description: taskForm.description,
        assignedDeveloperId: taskForm.assignedDeveloperId || null,
        priority: taskForm.priority,
        dueDate: taskForm.dueDate,
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["tasks", id] });
      setShowTaskForm(false);
      setTaskForm({ title: "", description: "", assignedDeveloperId: "", priority: "MEDIUM", dueDate: "" });
      setError(null);
    },
    onError: (err) => setError(extractErrorMessage(err)),
  });

  const canManage = user.role === "ADMIN" || (user.role === "PROJECT_MANAGER" && project?.createdById === user.id);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl font-bold text-slate-800">{project?.name ?? "Loading..."}</h1>
        <p className="text-sm text-slate-500">{project?.description}</p>
        <p className="mt-1 text-xs text-slate-400">
          Client: {project?.client?.company} · PM: {project?.createdBy?.name}
        </p>
      </div>

      <Card>
        <div className="flex flex-wrap items-center gap-3">
          <select
            value={status}
            onChange={(e) => updateFilter("status", e.target.value)}
            className="rounded-md border border-slate-300 px-3 py-1.5 text-sm"
          >
            <option value="">All statuses</option>
            {STATUS_OPTIONS.map((s) => (
              <option key={s} value={s}>
                {s.replace("_", " ")}
              </option>
            ))}
          </select>
          <select
            value={priority}
            onChange={(e) => updateFilter("priority", e.target.value)}
            className="rounded-md border border-slate-300 px-3 py-1.5 text-sm"
          >
            <option value="">All priorities</option>
            {PRIORITY_OPTIONS.map((p) => (
              <option key={p} value={p}>
                {p}
              </option>
            ))}
          </select>
          {(status || priority) && (
            <button onClick={() => setSearchParams({})} className="text-xs font-medium text-brand-600 hover:underline">
              Clear filters
            </button>
          )}

          {canManage && (
            <button
              onClick={() => setShowTaskForm((s) => !s)}
              className="ml-auto rounded-md bg-brand-600 px-4 py-1.5 text-sm font-semibold text-white hover:bg-brand-700"
            >
              {showTaskForm ? "Cancel" : "New Task"}
            </button>
          )}
        </div>
      </Card>

      {showTaskForm && (
        <Card>
          <form
            className="grid gap-3 sm:grid-cols-2"
            onSubmit={(e) => {
              e.preventDefault();
              createTask.mutate();
            }}
          >
            <input
              required
              placeholder="Task title"
              value={taskForm.title}
              onChange={(e) => setTaskForm({ ...taskForm, title: e.target.value })}
              className="rounded-md border border-slate-300 px-3 py-2 text-sm sm:col-span-2"
            />
            <textarea
              required
              placeholder="Description"
              value={taskForm.description}
              onChange={(e) => setTaskForm({ ...taskForm, description: e.target.value })}
              className="rounded-md border border-slate-300 px-3 py-2 text-sm sm:col-span-2"
            />
            <select
              value={taskForm.assignedDeveloperId}
              onChange={(e) => setTaskForm({ ...taskForm, assignedDeveloperId: e.target.value })}
              className="rounded-md border border-slate-300 px-3 py-2 text-sm"
            >
              <option value="">Unassigned</option>
              {developers?.map((d) => (
                <option key={d.id} value={d.id}>
                  {d.name}
                </option>
              ))}
            </select>
            <select
              value={taskForm.priority}
              onChange={(e) => setTaskForm({ ...taskForm, priority: e.target.value })}
              className="rounded-md border border-slate-300 px-3 py-2 text-sm"
            >
              {PRIORITY_OPTIONS.map((p) => (
                <option key={p} value={p}>
                  {p}
                </option>
              ))}
            </select>
            <input
              required
              type="date"
              value={taskForm.dueDate}
              onChange={(e) => setTaskForm({ ...taskForm, dueDate: e.target.value })}
              className="rounded-md border border-slate-300 px-3 py-2 text-sm sm:col-span-2"
            />
            {error && <p className="text-sm text-red-600 sm:col-span-2">{error}</p>}
            <button
              type="submit"
              disabled={createTask.isPending}
              className="rounded-md bg-brand-600 px-4 py-2 text-sm font-semibold text-white hover:bg-brand-700 sm:col-span-2"
            >
              Create Task
            </button>
          </form>
        </Card>
      )}

      <Card title="Tasks">
        {tasksLoading && <p className="text-sm text-slate-400">Loading tasks...</p>}
        {!tasksLoading && tasks?.length === 0 && (
          <p className="py-6 text-center text-sm text-slate-400">No tasks match these filters.</p>
        )}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead>
              <tr className="border-b border-slate-100 text-xs uppercase text-slate-400">
                <th className="py-2">Title</th>
                <th>Assignee</th>
                <th>Priority</th>
                <th>Status</th>
                <th>Due</th>
              </tr>
            </thead>
            <tbody>
              {tasks?.map((t) => (
                <TaskRow key={t.id} task={t} canEditStatus={user.role === "DEVELOPER" && t.assignedDeveloperId === user.id} />
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}

function TaskRow({ task, canEditStatus }: { task: Task; canEditStatus: boolean }) {
  const queryClient = useQueryClient();
  const updateStatus = useMutation({
    mutationFn: (status: string) => tasksApi.updateStatus(task.id, status),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["tasks"] }),
  });

  return (
    <tr className="border-b border-slate-50">
      <td className="py-2.5 font-medium text-slate-700">{task.title}</td>
      <td className="text-slate-500">{task.assignedDeveloper?.name ?? "Unassigned"}</td>
      <td>
        <PriorityBadge priority={task.priority} />
      </td>
      <td>
        {canEditStatus ? (
          <select
            value={task.status}
            onChange={(e) => updateStatus.mutate(e.target.value)}
            className="rounded-md border border-slate-300 px-2 py-1 text-xs"
          >
            {STATUS_OPTIONS.filter((s) => s !== "OVERDUE").map((s) => (
              <option key={s} value={s}>
                {s.replace("_", " ")}
              </option>
            ))}
          </select>
        ) : (
          <StatusBadge status={task.status} />
        )}
      </td>
      <td className="text-slate-500">{new Date(task.dueDate).toLocaleDateString()}</td>
    </tr>
  );
}
