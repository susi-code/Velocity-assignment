import bcrypt from "bcryptjs";
import { prisma } from "../config/prisma";
import { ApiError } from "../utils/ApiError";
import {
  hashToken,
  newJti,
  refreshExpiryDate,
  signAccessToken,
  signRefreshToken,
  verifyRefreshToken,
} from "../utils/tokens";

export async function login(email: string, password: string) {
  const user = await prisma.user.findUnique({ where: { email } });
  if (!user) throw new ApiError("UNAUTHENTICATED", "Invalid email or password");

  const valid = await bcrypt.compare(password, user.passwordHash);
  if (!valid) throw new ApiError("UNAUTHENTICATED", "Invalid email or password");

  const accessToken = signAccessToken({ sub: user.id, role: user.role, email: user.email });
  const { refreshToken } = await issueRefreshToken(user.id);

  return {
    accessToken,
    refreshToken,
    user: { id: user.id, name: user.name, email: user.email, role: user.role },
  };
}

async function issueRefreshToken(userId: string) {
  const jti = newJti();
  const refreshToken = signRefreshToken(userId, jti);
  await prisma.refreshToken.create({
    data: {
      id: jti,
      userId,
      tokenHash: hashToken(refreshToken),
      expiresAt: refreshExpiryDate(),
    },
  });
  return { refreshToken };
}

export async function refreshTokens(oldRefreshToken: string | undefined) {
  if (!oldRefreshToken) throw ApiError.unauthenticated("Missing refresh token");

  let payload;
  try {
    payload = verifyRefreshToken(oldRefreshToken);
  } catch {
    throw ApiError.unauthenticated("Invalid or expired refresh token");
  }

  const stored = await prisma.refreshToken.findUnique({ where: { id: payload.jti } });
  if (!stored || stored.revokedAt || stored.expiresAt < new Date()) {
    throw ApiError.unauthenticated("Refresh token is no longer valid");
  }
  if (stored.tokenHash !== hashToken(oldRefreshToken)) {
    throw ApiError.unauthenticated("Refresh token mismatch");
  }

  const user = await prisma.user.findUnique({ where: { id: stored.userId } });
  if (!user) throw ApiError.unauthenticated("User no longer exists");

  // Rotation: revoke old, issue new.
  await prisma.refreshToken.update({ where: { id: stored.id }, data: { revokedAt: new Date() } });
  const { refreshToken } = await issueRefreshToken(user.id);
  const accessToken = signAccessToken({ sub: user.id, role: user.role, email: user.email });

  return {
    accessToken,
    refreshToken,
    user: { id: user.id, name: user.name, email: user.email, role: user.role },
  };
}

export async function logout(refreshToken: string | undefined) {
  if (!refreshToken) return;
  try {
    const payload = verifyRefreshToken(refreshToken);
    await prisma.refreshToken.updateMany({
      where: { id: payload.jti, revokedAt: null },
      data: { revokedAt: new Date() },
    });
  } catch {
    // Token already invalid/expired - nothing to revoke.
  }
}
