import { useEffect, useRef, useState } from "react";
import { activityApi } from "../api/endpoints";
import { ActivityLog } from "../types";
import { useSocket } from "./useSocket";

export function useActivityFeed() {
  const [activities, setActivities] = useState<ActivityLog[]>([]);
  const lastSeenRef = useRef<string | null>(null);

  useEffect(() => {
    activityApi.recent().then((res) => {
      const data = res.data.data;
      setActivities(data);
      if (data.length > 0) lastSeenRef.current = data[0].createdAt;
    });
  }, []);

  useSocket({
    onActivityNew: (payload) => {
      const activity = payload as ActivityLog;
      lastSeenRef.current = activity.createdAt;
      setActivities((prev) => [activity, ...prev].slice(0, 50));
    },
  });

  // On reconnect (tab regains focus after being backgrounded), pull anything missed.
  useEffect(() => {
    function handleVisibility() {
      if (document.visibilityState === "visible" && lastSeenRef.current) {
        activityApi.catchup(lastSeenRef.current).then((res) => {
          if (res.data.data.length === 0) return;
          setActivities((prev) => {
            const merged = [...res.data.data.reverse(), ...prev];
            lastSeenRef.current = merged[0]?.createdAt ?? lastSeenRef.current;
            return merged.slice(0, 50);
          });
        });
      }
    }
    document.addEventListener("visibilitychange", handleVisibility);
    return () => document.removeEventListener("visibilitychange", handleVisibility);
  }, []);

  return activities;
}
