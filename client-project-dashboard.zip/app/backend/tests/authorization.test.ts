/**
 * These tests hit a real running Postgres database (via Prisma) that has been
 * migrated AND seeded, exactly like the real app. Run:
 *
 *   docker compose up -d
 *   npx prisma migrate dev
 *   npx prisma db seed
 *   npm test
 *
 * They intentionally do not mock Prisma or Express, because the whole point
 * of these tests is proving that authorization is enforced at the real
 * API/DB layer, not just in application logic.
 */
import { describe, it, expect, beforeAll } from "vitest";
import request from "supertest";
import { createApp } from "../src/app";

const app = createApp();
const PASSWORD = "Password123!";

async function loginAs(email: string) {
  const res = await request(app).post("/api/auth/login").send({ email, password: PASSWORD });
  return res.body.data.accessToken as string;
}

describe("Authentication & Authorization", () => {
  let adminToken: string;
  let pm1Token: string;
  let pm2Token: string;
  let dev1Token: string;
  let dev2Token: string;

  beforeAll(async () => {
    adminToken = await loginAs("admin@example.com");
    pm1Token = await loginAs("pm1@example.com");
    pm2Token = await loginAs("pm2@example.com");
    dev1Token = await loginAs("developer1@example.com");
    dev2Token = await loginAs("developer2@example.com");
  });

  it("rejects requests with no token", async () => {
    const res = await request(app).get("/api/projects");
    expect(res.status).toBe(401);
    expect(res.body.success).toBe(false);
  });

  it("admin can list all projects", async () => {
    const res = await request(app).get("/api/projects").set("Authorization", `Bearer ${adminToken}`);
    expect(res.status).toBe(200);
    expect(res.body.data.length).toBeGreaterThanOrEqual(3);
  });

  it("PM1 can access their own project", async () => {
    const list = await request(app).get("/api/projects").set("Authorization", `Bearer ${pm1Token}`);
    const projectId = list.body.data[0].id;
    const res = await request(app).get(`/api/projects/${projectId}`).set("Authorization", `Bearer ${pm1Token}`);
    expect(res.status).toBe(200);
  });

  it("PM2 CANNOT access a project owned by PM1", async () => {
    const pm1List = await request(app).get("/api/projects").set("Authorization", `Bearer ${pm1Token}`);
    const pm1ProjectId = pm1List.body.data[0].id;

    const res = await request(app)
      .get(`/api/projects/${pm1ProjectId}`)
      .set("Authorization", `Bearer ${pm2Token}`);
    expect([403, 404]).toContain(res.status);
  });

  it("Developer1 can access their assigned task but not developer2's task", async () => {
    const mine = await request(app).get("/api/tasks/mine").set("Authorization", `Bearer ${dev1Token}`);
    expect(mine.status).toBe(200);
    expect(mine.body.data.length).toBeGreaterThan(0);
    const myTaskId = mine.body.data[0].id;

    const ok = await request(app).get(`/api/tasks/${myTaskId}`).set("Authorization", `Bearer ${dev1Token}`);
    expect(ok.status).toBe(200);

    const forbidden = await request(app)
      .get(`/api/tasks/${myTaskId}`)
      .set("Authorization", `Bearer ${dev2Token}`);
    expect(forbidden.status).toBe(403);
  });

  it("Developer cannot update another developer's task status", async () => {
    const mine = await request(app).get("/api/tasks/mine").set("Authorization", `Bearer ${dev1Token}`);
    const myTaskId = mine.body.data[0].id;

    const res = await request(app)
      .patch(`/api/tasks/${myTaskId}/status`)
      .set("Authorization", `Bearer ${dev2Token}`)
      .send({ status: "IN_PROGRESS" });
    expect(res.status).toBe(403);
  });

  it("Developer CAN update their own task's status, and it creates an activity log entry", async () => {
    const mine = await request(app).get("/api/tasks/mine").set("Authorization", `Bearer ${dev1Token}`);
    const task = mine.body.data.find((t: { status: string }) => t.status === "TODO") ?? mine.body.data[0];

    const res = await request(app)
      .patch(`/api/tasks/${task.id}/status`)
      .set("Authorization", `Bearer ${dev1Token}`)
      .send({ status: "IN_PROGRESS" });
    expect(res.status).toBe(200);
    expect(res.body.data.status).toBe("IN_PROGRESS");

    const activity = await request(app).get("/api/activity").set("Authorization", `Bearer ${dev1Token}`);
    const found = activity.body.data.find((a: { taskId: string }) => a.taskId === task.id);
    expect(found).toBeTruthy();
  });

  it("Non-admin cannot access admin-only user list", async () => {
    const res = await request(app).get("/api/users").set("Authorization", `Bearer ${pm1Token}`);
    expect(res.status).toBe(403);
  });
});
