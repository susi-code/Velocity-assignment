import { Router } from "express";
import { authenticate, authorizeRoles } from "../middleware/auth";
import { asyncHandler } from "../middleware/errorHandler";
import * as userService from "../services/userService";
import { createUserSchema } from "../validators/schemas";

const router = Router();
router.use(authenticate);

router.get(
  "/",
  authorizeRoles("ADMIN"),
  asyncHandler(async (_req, res) => {
    const users = await userService.listUsers();
    res.json({ success: true, data: users });
  })
);

// Any authenticated PM/Admin needs this to populate an "assign developer" dropdown.
router.get(
  "/developers",
  authorizeRoles("ADMIN", "PROJECT_MANAGER"),
  asyncHandler(async (_req, res) => {
    const developers = await userService.listDevelopers();
    res.json({ success: true, data: developers });
  })
);

router.post(
  "/",
  authorizeRoles("ADMIN"),
  asyncHandler(async (req, res) => {
    const body = createUserSchema.parse(req.body);
    const user = await userService.createUser(body);
    res.status(201).json({ success: true, data: user });
  })
);

export default router;
