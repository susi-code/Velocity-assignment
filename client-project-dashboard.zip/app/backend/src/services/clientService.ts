import { prisma } from "../config/prisma";

export async function listClients() {
  return prisma.client.findMany({ orderBy: { name: "asc" } });
}

export async function createClient(data: { name: string; email: string; company: string }) {
  return prisma.client.create({ data });
}
