import { Server as HttpServer } from "http";
import { Server, Socket } from "socket.io";
import { verifyAccessToken } from "../utils/tokens";
import { prisma } from "../config/prisma";
import { env } from "../config/env";
import { Role } from "@prisma/client";

interface SocketUser {
  id: string;
  role: Role;
  email: string;
}

// userId -> count of connected sockets (a user may have multiple tabs)
const onlineUsers = new Map<string, number>();

let io: Server | null = null;

export function getIo(): Server {
  if (!io) throw new Error("Socket.io not initialized");
  return io;
}

export function initSockets(server: HttpServer) {
  io = new Server(server, {
    cors: { origin: env.clientUrl, credentials: true },
  });

  io.use((socket, next) => {
    try {
      const token = socket.handshake.auth?.token as string | undefined;
      if (!token) return next(new Error("Unauthorized"));
      const payload = verifyAccessToken(token);
      (socket.data as { user: SocketUser }).user = {
        id: payload.sub,
        role: payload.role,
        email: payload.email,
      };
      return next();
    } catch {
      return next(new Error("Unauthorized"));
    }
  });

  io.on("connection", (socket: Socket) => {
    void handleConnection(socket);
  });

  return io;
}

async function handleConnection(socket: Socket) {
  const user = (socket.data as { user: SocketUser }).user;

  // Every user gets a personal room for direct notifications/task updates.
  socket.join(`user:${user.id}`);

  // Admins get the global activity room.
  if (user.role === "ADMIN") {
    socket.join("global:activity");
  }

  // Join a room for every project this user is authorized to see,
  // so we can scope `activity:new` / `task:updated` broadcasts safely.
  const projectIds = await getAuthorizedProjectIds(user);
  for (const pid of projectIds) {
    socket.join(`project:${pid}`);
  }

  // Presence tracking.
  const prevCount = onlineUsers.get(user.id) ?? 0;
  onlineUsers.set(user.id, prevCount + 1);
  if (prevCount === 0) {
    getIo().to("global:activity").emit("presence:user-online", { userId: user.id });
  }
  broadcastPresenceCount();

  socket.on("disconnect", () => {
    const count = (onlineUsers.get(user.id) ?? 1) - 1;
    if (count <= 0) {
      onlineUsers.delete(user.id);
      getIo().to("global:activity").emit("presence:user-offline", { userId: user.id });
    } else {
      onlineUsers.set(user.id, count);
    }
    broadcastPresenceCount();
  });
}

function broadcastPresenceCount() {
  getIo().to("global:activity").emit("presence:count", { count: onlineUsers.size });
}

export function getOnlineCount(): number {
  return onlineUsers.size;
}

/** Returns the project ids a given user is authorized to see activity/rooms for. */
export async function getAuthorizedProjectIds(user: SocketUser): Promise<string[]> {
  if (user.role === "ADMIN") {
    const projects = await prisma.project.findMany({ select: { id: true } });
    return projects.map((p) => p.id);
  }
  if (user.role === "PROJECT_MANAGER") {
    const projects = await prisma.project.findMany({
      where: { createdById: user.id },
      select: { id: true },
    });
    return projects.map((p) => p.id);
  }
  // DEVELOPER: projects where they have at least one assigned task
  const tasks = await prisma.task.findMany({
    where: { assignedDeveloperId: user.id },
    select: { projectId: true },
    distinct: ["projectId"],
  });
  return tasks.map((t) => t.projectId);
}

/**
 * Emits an activity event to everyone authorized to see it:
 * - global:activity room (admins)
 * - project:{id} room, BUT only developers assigned to the related task should see it there.
 * Since room membership alone is not sufficient authorization (a developer is only
 * placed into a project room because they have SOME task there, not because they should
 * see ALL activity in that project), we resolve per-socket recipients explicitly instead
 * of broadcasting blindly to the whole project room.
 */
export async function emitActivity(payload: {
  id: string;
  projectId: string;
  taskId: string | null;
  userId: string;
  action: string;
  oldValue: string | null;
  newValue: string | null;
  createdAt: Date;
}) {
  const ioServer = getIo();

  // Admins: always see everything.
  ioServer.to("global:activity").emit("activity:new", payload);

  // Project manager who owns the project.
  const project = await prisma.project.findUnique({ where: { id: payload.projectId } });
  if (project) {
    ioServer.to(`user:${project.createdById}`).emit("activity:new", payload);
  }

  // Developer(s) - only the developer assigned to the related task, if any.
  if (payload.taskId) {
    const task = await prisma.task.findUnique({ where: { id: payload.taskId } });
    if (task?.assignedDeveloperId) {
      ioServer.to(`user:${task.assignedDeveloperId}`).emit("activity:new", payload);
    }
  }
}

export function emitTaskUpdated(task: { id: string; projectId: string; assignedDeveloperId: string | null }) {
  const ioServer = getIo();
  ioServer.to(`project:${task.projectId}`).emit("task:updated", task);
  if (task.assignedDeveloperId) {
    ioServer.to(`user:${task.assignedDeveloperId}`).emit("task:updated", task);
  }
}

export function emitNotification(recipientId: string, notification: unknown) {
  getIo().to(`user:${recipientId}`).emit("notification:new", notification);
}

export function emitNotificationCount(recipientId: string, count: number) {
  getIo().to(`user:${recipientId}`).emit("notification:count", { count });
}
